#!/usr/bin/env python3
import argparse
import asyncio
import csv
import json
import os
import re
import sys
import urllib.request
import urllib.parse
from datetime import datetime

from telethon import TelegramClient
from telethon.errors import (
    ChannelInvalidError,
    ChannelPrivateError,
    FloodWaitError,
    UsernameInvalidError,
    UsernameNotOccupiedError,
)
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.channels import GetFullChannelRequest
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import Channel, Chat, User


def _load_env():
    path = os.path.join(os.getcwd(), ".env")
    if not os.path.exists(path):
        return
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except Exception:
        pass


_load_env()

BANNER = r"""
 ████████╗███████╗██╗     ███████╗ ██████╗ ██████╗  █████╗ ███╗   ███╗
 ╚══██╔══╝██╔════╝██║     ██╔════╝██╔════╝ ██╔══██╗██╔══██╗████╗ ████║
    ██║   █████╗  ██║     █████╗  ██║  ███╗██████╔╝███████║██╔████╔██║
    ██║   ██╔══╝  ██║     ██╔══╝  ██║   ██║██╔══██╗██╔══██║██║╚██╔╝██║
    ██║   ███████╗███████╗███████╗╚██████╔╝██║  ██║██║  ██║██║ ╚═╝ ██║
    ╚═╝   ╚══════╝╚══════╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝
        ██████╗██╗  ██╗███████╗ ██████╗██╗  ██╗███████╗██████╗
       ██╔════╝██║  ██║██╔════╝██╔════╝██║ ██╔╝██╔════╝██╔══██╗
       ██║     ███████║█████╗  ██║     █████╔╝ █████╗  ██████╔╝
       ██║     ██╔══██║██╔══╝  ██║     ██╔═██╗ ██╔══╝  ██╔══██╗
       ╚██████╗██║  ██║███████╗╚██████╗██║  ██╗███████╗██║  ██║
        ╚═════╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
          Channel & Username Availability Checker
                    by Dark Web Informer
"""

API_ID = os.getenv("TELEGRAM_API_ID", "")
API_HASH = os.getenv("TELEGRAM_API_HASH", "")
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
BOT_CHAT_ID = os.getenv("TELEGRAM_BOT_CHAT_ID", "")
SESSION_NAME = "channel_checker_session"

DEFAULT_DELAY = 3.0
DEFAULT_CONCURRENCY = 3
MAX_RETRIES = 3

AVAIL_ICON = {"available": "🟢", "taken": "🔴", "invalid": "⚪", "unknown": "🟡"}
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[96m"
RED = "\033[91m"
GREEN = "\033[92m"
AVAIL_COLOR = {"available": "\033[92m", "taken": "\033[91m", "invalid": "\033[90m", "unknown": "\033[93m"}

USERNAME_CANDIDATES = ("telegram_channel", "channel", "username", "url", "link", "telegram", "handle")
LABEL_CANDIDATES = ("threat_actor", "actor", "label", "name", "source", "group", "owner")
SUGGEST_SUFFIXES = ("_official", "_real", "_hq", "_tg", "_channel", "official", "real", "hq", "_")

_USERNAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{3,30}[A-Za-z0-9]$")


def validate_username_format(username):
    if not (5 <= len(username) <= 32):
        return False
    if "__" in username:
        return False
    return bool(_USERNAME_RE.match(username))


def extract_username(value):
    value = (value or "").strip()
    if not value:
        return None
    m = re.match(r"https?://t\.me/([^/?#]+)", value, re.IGNORECASE)
    if m:
        username = m.group(1)
    elif value.startswith("@"):
        username = value[1:]
    else:
        username = value
    if username.startswith("+"):
        return None
    if username.lower() in ("c", "s", "joinchat", "addstickers", "+", "proxy", "socks"):
        return None
    return username or None


def find_username_column(fieldnames, rows):
    for cand in USERNAME_CANDIDATES:
        for fn in fieldnames:
            if fn and fn.strip().lower() == cand:
                return fn
    best, best_hits = None, 0
    for fn in fieldnames:
        hits = 0
        for r in rows[:100]:
            v = (r.get(fn) or "").lower()
            if "t.me/" in v or v.strip().startswith("@"):
                hits += 1
        if hits > best_hits:
            best, best_hits = fn, hits
    return best


def find_label_column(fieldnames, username_col):
    for cand in LABEL_CANDIDATES:
        for fn in fieldnames:
            if fn and fn.strip().lower() == cand and fn != username_col:
                return fn
    for fn in fieldnames:
        if fn and fn != username_col:
            return fn
    return None


def generate_variants(username):
    base = username.rstrip("_")
    cands = [base + s for s in SUGGEST_SUFFIXES]
    for i in range(1, 6):
        cands.append(f"{base}{i}")
        cands.append(f"{base}0{i}")
    cands.append(f"the{base}")
    cands.append(f"{base}_{base[:3]}")
    out, seen = [], set()
    for c in cands:
        cl = c.lower()
        if cl in seen or cl == username.lower():
            continue
        seen.add(cl)
        if validate_username_format(c):
            out.append(c)
    return out


class RateLimiter:
    def __init__(self, interval):
        self.interval = max(0.0, interval)
        self._lock = asyncio.Lock()
        self._next = 0.0

    async def wait(self):
        if self.interval <= 0:
            return
        async with self._lock:
            loop = asyncio.get_running_loop()
            now = loop.time()
            if now < self._next:
                await asyncio.sleep(self._next - now)
                now = loop.time()
            self._next = now + self.interval


class FloodGate:
    def __init__(self):
        self._event = asyncio.Event()
        self._event.set()
        self._until = 0.0
        self._lock = asyncio.Lock()

    async def wait(self):
        while not self._event.is_set():
            await self._event.wait()

    async def trip(self, seconds):
        loop = asyncio.get_running_loop()
        async with self._lock:
            self._until = max(self._until, loop.time() + seconds)
            self._event.clear()
        while True:
            remaining = self._until - loop.time()
            if remaining <= 0:
                break
            await asyncio.sleep(remaining)
        async with self._lock:
            if loop.time() >= self._until:
                self._event.set()


def _blank_result():
    return {
        "status": "unknown", "availability": "unknown", "title": "",
        "member_count": "", "channel_type": "", "error": "",
        "verified": "", "scam": "", "fake": "", "restricted": "",
        "about": "", "last_activity": "", "suggestions": "",
    }


async def check_channel(client, username, fetch_meta=True, gate=None):
    result = _blank_result()

    if not validate_username_format(username):
        result["status"] = "invalid"
        result["availability"] = "invalid"
        result["error"] = "Does not meet Telegram username format rules (5-32 chars, letters/digits/underscore, start with a letter)"
        return result

    retries = 0
    while retries <= MAX_RETRIES:
        if gate is not None:
            await gate.wait()
        try:
            entity = await client.get_entity(username)

            result["status"] = "active"
            result["availability"] = "taken"
            result["title"] = getattr(entity, "title", getattr(entity, "first_name", "")) or ""
            result["verified"] = "yes" if getattr(entity, "verified", False) else ""
            result["scam"] = "yes" if getattr(entity, "scam", False) else ""
            result["fake"] = "yes" if getattr(entity, "fake", False) else ""
            result["restricted"] = "yes" if getattr(entity, "restricted", False) else ""

            if getattr(entity, "participants_count", None):
                result["member_count"] = str(entity.participants_count)

            if isinstance(entity, Channel):
                if entity.megagroup:
                    result["channel_type"] = "supergroup"
                elif getattr(entity, "gigagroup", False):
                    result["channel_type"] = "gigagroup"
                else:
                    result["channel_type"] = "channel"
            elif isinstance(entity, Chat):
                result["channel_type"] = "group"
            elif isinstance(entity, User):
                result["channel_type"] = "bot" if getattr(entity, "bot", False) else "user"
            else:
                result["channel_type"] = type(entity).__name__

            if fetch_meta:
                try:
                    if isinstance(entity, Channel):
                        full = await client(GetFullChannelRequest(entity))
                        result["about"] = getattr(full.full_chat, "about", "") or ""
                        if not result["member_count"]:
                            pc = getattr(full.full_chat, "participants_count", None)
                            result["member_count"] = str(pc) if pc else ""
                    elif isinstance(entity, User):
                        full = await client(GetFullUserRequest(entity))
                        fu = getattr(full, "full_user", None)
                        result["about"] = getattr(fu, "about", "") or "" if fu else ""
                except Exception:
                    pass
                try:
                    msgs = await client.get_messages(entity, limit=1)
                    if msgs:
                        result["last_activity"] = msgs[0].date.strftime("%Y-%m-%d")
                except Exception:
                    pass

            return result

        except UsernameNotOccupiedError:
            result["status"] = "not_found"
            result["availability"] = "available"
            result["error"] = "Username is not occupied - free to register"
            return result

        except UsernameInvalidError:
            result["status"] = "invalid"
            result["availability"] = "invalid"
            result["error"] = "Invalid username format (rejected by Telegram)"
            return result

        except ChannelPrivateError:
            result["status"] = "private_or_banned"
            result["availability"] = "taken"
            result["error"] = "Channel is private or has been banned"
            return result

        except ChannelInvalidError:
            result["status"] = "invalid_channel"
            result["availability"] = "unknown"
            result["error"] = "Channel reference is invalid"
            return result

        except FloodWaitError as e:
            retries += 1
            if retries > MAX_RETRIES:
                result["status"] = "error"
                result["availability"] = "unknown"
                result["error"] = f"FloodWait exceeded after {MAX_RETRIES} retries"
                return result
            wait_time = min(e.seconds + 5, 300)
            if gate is not None:
                await gate.trip(wait_time)
            else:
                await asyncio.sleep(min(wait_time, 120))

        except ValueError as e:
            msg = str(e).lower()
            if any(s in msg for s in ("no user has", "nobody is using this username",
                                      "cannot find any entity", "no such", "could not find the input entity")):
                result["status"] = "not_found"
                result["availability"] = "available"
                result["error"] = "Username is not occupied - free to register"
            else:
                result["status"] = "error"
                result["availability"] = "unknown"
                result["error"] = str(e)[:200]
            return result

        except Exception as e:
            result["status"] = "error"
            result["availability"] = "unknown"
            result["error"] = str(e)[:200]
            return result

    return result


async def check_one(client, sem, rate, gate, username, fetch_meta):
    async with sem:
        await rate.wait()
        res = await check_channel(client, username, fetch_meta, gate)
        res["username"] = username
        return res


async def suggest_available(client, sem, rate, gate, username, count):
    found = []
    for v in generate_variants(username):
        if len(found) >= count:
            break
        r = await check_one(client, sem, rate, gate, v, False)
        if r["availability"] == "available":
            found.append(v)
    return found


def _make_progress(total):
    try:
        from tqdm import tqdm
        return tqdm(total=total, unit="name", ncols=72, leave=False)
    except Exception:
        return _SimpleBar(total)


class _SimpleBar:
    def __init__(self, total):
        self.total = total
        self.n = 0

    def update(self, k=1):
        self.n += k
        print(f"\r  checked {self.n}/{self.total}", end="", flush=True)

    def close(self):
        print("\r" + " " * 24 + "\r", end="")


async def run_checks(client, usernames, sem, rate, gate, fetch_meta, progress, on_result=None):
    tasks = [asyncio.create_task(check_one(client, sem, rate, gate, u, fetch_meta)) for u in usernames]
    bar = _make_progress(len(tasks)) if progress else None
    results = []
    for coro in asyncio.as_completed(tasks):
        r = await coro
        if on_result is not None:
            await on_result(r)
        results.append(r)
        if bar:
            bar.update(1)
    if bar:
        bar.close()
    order = {u: i for i, u in enumerate(usernames)}
    results.sort(key=lambda r: order.get(r["username"], 0))
    return results


def config_ok():
    if not API_ID or not API_HASH or "YOUR_" in str(API_ID) or "YOUR_" in str(API_HASH):
        print("Please set your API_ID and API_HASH before running.")
        print("Get them from https://my.telegram.org, then set env vars or a .env file:")
        print("  TELEGRAM_API_ID=12345")
        print('  TELEGRAM_API_HASH="abcdef1234567890"')
        return False
    if not str(API_ID).strip().isdigit():
        print("TELEGRAM_API_ID must be a number (digits only).")
        return False
    return True


def secure_session_file():
    if os.name != "posix":
        return
    path = SESSION_NAME + ".session"
    try:
        if os.path.exists(path):
            os.chmod(path, 0o600)
    except Exception:
        pass


def load_input_file(path):
    if not os.path.exists(path):
        print(f"File not found: {path}")
        return []
    if path.lower().endswith(".csv"):
        with open(path, encoding="utf-8") as f:
            reader = csv.DictReader(f)
            fns = reader.fieldnames or []
            rows = list(reader)
        uc = find_username_column(fns, rows)
        if not uc:
            print(f"Could not find a username column in {path} (columns: {', '.join(fns)})")
            return []
        lc = find_label_column(fns, uc)
        return [(r.get(uc, ""), (r.get(lc, "") if lc else "")) for r in rows]
    with open(path, encoding="utf-8") as f:
        return [(line.strip(), "") for line in f if line.strip()]


def collect_targets(args):
    entries = [(t, "") for t in (args.targets or [])]
    if args.input:
        entries.extend(load_input_file(args.input))
    use_stdin = args.stdin
    if not use_stdin and not args.targets and not args.input:
        try:
            use_stdin = not sys.stdin.isatty()
        except Exception:
            use_stdin = False
    if use_stdin:
        for line in sys.stdin:
            line = line.strip()
            if line:
                entries.append((line, ""))
    umap = {}
    for value, label in entries:
        u = extract_username(value)
        if not u:
            continue
        k = u.lower()
        if k not in umap:
            umap[k] = {"username": u, "labels": set()}
        if label:
            umap[k]["labels"].add(label)
    return umap


def flag_str(r):
    parts = [n for n in ("verified", "scam", "fake", "restricted") if r.get(n)]
    if not parts:
        return ""
    color = RED if ("scam" in parts or "fake" in parts) else GREEN
    return f"{color}{', '.join(parts)}{RESET}"


_CTRL_RE = re.compile(r"[\x00-\x1f\x7f-\x9f]")


def term_safe(value):
    return _CTRL_RE.sub(" ", str(value or "")).strip()


def csv_safe(value):
    s = "" if value is None else str(value)
    if s[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + s
    return s


def print_result_card(username, status):
    avail = status["availability"]
    icon = AVAIL_ICON.get(avail, "🟡")
    color = AVAIL_COLOR.get(avail, AVAIL_COLOR["unknown"])
    bar = f"{color}│{RESET}"
    fields = [("Username", f"@{term_safe(username)}"), ("Link", f"https://t.me/{term_safe(username)}")]
    if status.get("title"):
        fields.append(("Title", term_safe(status["title"])))
    if status.get("channel_type"):
        fields.append(("Type", status["channel_type"]))
    if status.get("member_count"):
        mc = str(status["member_count"])
        fields.append(("Members", f"{int(mc):,}" if mc.isdigit() else mc))
    flags = flag_str(status)
    if flags:
        fields.append(("Flags", flags))
    if status.get("last_activity"):
        fields.append(("Last seen", status["last_activity"]))
    if status.get("about"):
        about = " ".join(term_safe(status["about"]).split())
        fields.append(("About", about[:57] + "..." if len(about) > 60 else about))
    if status.get("suggestions"):
        fields.append(("Suggestions", status["suggestions"]))
    if status.get("error"):
        fields.append(("Note", term_safe(status["error"])))
    print()
    print(f"{color}╭─ Telegram Check {'─' * 30}{RESET}")
    print(bar)
    print(f"{bar}   {icon}  {color}{BOLD}{avail.upper()}{RESET}")
    print(bar)
    for k, v in fields:
        tint = CYAN if k in ("Username", "Link") else ""
        print(f"{bar}   {DIM}{k:<11}{RESET}{tint}{v}{RESET}")
    print(bar)
    print(f"{color}╰{'─' * 46}{RESET}")
    print()


def print_result_line(r):
    avail = r["availability"]
    icon = AVAIL_ICON.get(avail, "🟡")
    color = AVAIL_COLOR.get(avail, AVAIL_COLOR["unknown"])
    parts = [f"  {icon} {color}{avail.upper():<9}{RESET} @{term_safe(r['username'])}"]
    if r.get("title"):
        parts.append(f"{DIM}{term_safe(r['title'])}{RESET}")
    mc = str(r.get("member_count", "") or "")
    if mc.isdigit():
        parts.append(f"{DIM}({int(mc):,}){RESET}")
    fl = flag_str(r)
    if fl:
        parts.append(fl)
    print("  ".join(parts))
    if r.get("suggestions"):
        print(f"        {DIM}↳ try: {r['suggestions']}{RESET}")


def print_summary(results):
    counts = {}
    for r in results:
        counts[r["availability"]] = counts.get(r["availability"], 0) + 1
    print(f"\n{DIM}{'─' * 40}{RESET}")
    for a in ("available", "taken", "invalid", "unknown"):
        if a in counts:
            print(f"  {AVAIL_ICON.get(a, '🟡')} {a}: {counts[a]}")
    print(f"{DIM}{'─' * 40}{RESET}")


OUT_FIELDS = [
    "label", "username", "telegram_channel", "availability", "status", "title",
    "channel_type", "member_count", "verified", "scam", "fake", "restricted",
    "about", "last_activity", "suggestions", "error",
]


def write_csv(path, results):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=OUT_FIELDS)
        w.writeheader()
        for r in results:
            w.writerow({k: csv_safe(r.get(k, "")) for k in OUT_FIELDS})


def write_json(path, results):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)


def resolve_output(args):
    if args.output:
        return args.output
    if args.input and args.input.lower().endswith(".csv"):
        return os.path.splitext(args.input)[0] + "_status.csv"
    return None


class CsvWriter:
    def __init__(self, path, resume):
        self.path = path
        self.done = set()
        resuming = resume and os.path.exists(path)
        if resuming:
            try:
                with open(path, encoding="utf-8") as f:
                    for row in csv.DictReader(f):
                        if row.get("username"):
                            self.done.add(row["username"].lower())
            except Exception:
                self.done = set()
                resuming = False
        self._f = open(path, "a" if resuming else "w", newline="", encoding="utf-8")
        self._w = csv.DictWriter(self._f, fieldnames=OUT_FIELDS)
        if not resuming:
            self._w.writeheader()
        self._f.flush()

    def write(self, r):
        self._w.writerow({k: csv_safe(r.get(k, "")) for k in OUT_FIELDS})
        self._f.flush()

    def close(self):
        try:
            self._f.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Bot notifications (Telegram Bot API, separate from the user account client)
# ---------------------------------------------------------------------------

def bot_configured():
    return bool(BOT_TOKEN and BOT_CHAT_ID)


def _bot_api_call(method, payload, timeout=10):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
    data = urllib.parse.urlencode(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        print(f"{DIM}[bot] notify failed: {e}{RESET}")
        return None


def notify(text):
    if not bot_configured():
        return
    _bot_api_call("sendMessage", {
        "chat_id": BOT_CHAT_ID,
        "text": text[:4000],
        "parse_mode": "HTML",
        "disable_web_page_preview": "true",
    })


def format_notify_message(r):
    avail = r["availability"]
    icon = AVAIL_ICON.get(avail, "🟡")
    lines = [f"{icon} <b>{avail.upper()}</b>  @{term_safe(r['username'])}"]
    lines.append(f"https://t.me/{term_safe(r['username'])}")
    if r.get("title"):
        lines.append(f"Title: {term_safe(r['title'])}")
    if r.get("channel_type"):
        lines.append(f"Type: {r['channel_type']}")
    mc = str(r.get("member_count", "") or "")
    if mc.isdigit():
        lines.append(f"Members: {int(mc):,}")
    fl_parts = [n for n in ("verified", "scam", "fake", "restricted") if r.get(n)]
    if fl_parts:
        lines.append(f"Flags: {', '.join(fl_parts)}")
    if r.get("suggestions"):
        lines.append(f"Suggestions: {r['suggestions']}")
    if r.get("error") and avail not in ("available", "taken"):
        lines.append(f"Note: {term_safe(r['error'])}")
    label = r.get("label")
    if label:
        lines.append(f"Label: {term_safe(label)}")
    return "\n".join(lines)


async def maybe_notify(r, args):
    if not args.notify or not bot_configured():
        return
    if args.notify_all or r["availability"] == "available":
        notify(format_notify_message(r))


# ---------------------------------------------------------------------------


async def do_round(client, umap, args, fetch_meta, progress=True, apply_filter=True, writer=None, done=None):
    done = done or set()
    sem = asyncio.Semaphore(max(1, args.concurrency))
    rate = RateLimiter(args.delay)
    gate = FloodGate()
    usernames = [v["username"] for v in umap.values() if v["username"].lower() not in done]

    async def enrich(r):
        u = r["username"]
        info = umap.get(u.lower(), {})
        r["telegram_channel"] = f"https://t.me/{u}"
        r["label"] = " / ".join(sorted(info.get("labels", []))) if info.get("labels") else ""
        r.setdefault("suggestions", "")
        if args.suggest and r["availability"] != "available":
            r["suggestions"] = ", ".join(await suggest_available(client, sem, rate, gate, u, args.suggest_count))

    async def on_result(r):
        await enrich(r)
        if writer is not None:
            writer.write(r)
        await maybe_notify(r, args)

    results = await run_checks(client, usernames, sem, rate, gate, fetch_meta,
                               progress and len(usernames) > 1, on_result)
    if apply_filter and args.available_only:
        results = [r for r in results if r["availability"] == "available"]
    return results


def present_results(results, args, out=None, wrote_csv=False):
    if not results:
        print("No new results to show." if wrote_csv else "No matching results.")
    elif len(results) == 1:
        print_result_card(results[0]["username"], results[0])
    else:
        print()
        for r in results:
            print_result_line(r)
        print_summary(results)
    if wrote_csv and out:
        print(f"\n{DIM}Saved CSV  -> {out}{RESET}")


async def watch_loop(client, umap, args, fetch_meta):
    interval = args.watch
    print(f"{DIM}Watch mode: re-checking {len(umap)} target(s) every {interval:g}s. Ctrl+C to stop.{RESET}\n")
    if args.notify and bot_configured():
        print(f"{DIM}Bot notifications: ON (chat {BOT_CHAT_ID}){RESET}\n")
    prev = {}
    round_no = 0
    while True:
        round_no += 1
        ts = datetime.now().strftime("%H:%M:%S")
        results = await do_round(client, umap, args, fetch_meta, progress=False, apply_filter=False)
        changes = []
        for r in results:
            cur = r["availability"]
            old = prev.get(r["username"].lower())
            if old is not None and old != cur:
                changes.append((r["username"], old, cur))
            prev[r["username"].lower()] = cur
        if round_no == 1:
            print(f"{DIM}[{ts}] baseline{RESET}")
            for r in results:
                print_result_line(r)
        elif changes:
            print(f"[{ts}] {len(changes)} change(s):")
            for u, old, new in changes:
                c = AVAIL_COLOR.get(new, "")
                print(f"  🔁 @{term_safe(u)}: {old} -> {c}{new}{RESET}")
                if args.notify and bot_configured():
                    notify(f"🔁 <b>CHANGED</b>  @{term_safe(u)}\n{old} → <b>{new}</b>\nhttps://t.me/{term_safe(u)}")
        else:
            print(f"{DIM}[{ts}] no changes{RESET}")
        await asyncio.sleep(interval)


async def run(args):
    if not config_ok():
        return
    if args.notify and not bot_configured():
        print(f"{DIM}--notify was set but TELEGRAM_BOT_TOKEN/TELEGRAM_BOT_CHAT_ID are missing in .env — notifications disabled.{RESET}")
    umap = collect_targets(args)
    if not umap:
        print("No valid targets. Pass usernames/URLs, --input FILE, or pipe via stdin.")
        return
    fetch_meta = not args.no_meta
    client = TelegramClient(SESSION_NAME, int(API_ID), API_HASH)
    await client.start()
    secure_session_file()
    try:
        if args.watch:
            if args.output or args.json or args.resume:
                print(f"{DIM}Note: --output/--json/--resume are not used in watch mode.{RESET}")
            await watch_loop(client, umap, args, fetch_meta)
            return

        out = resolve_output(args)
        writer = CsvWriter(out, args.resume) if out else None
        try:
            if writer and writer.done:
                skip = sum(1 for k in umap if k in writer.done)
                if skip:
                    print(f"{DIM}Resume: {skip} target(s) already in {out}, skipping.{RESET}")
            results = await do_round(client, umap, args, fetch_meta, progress=True,
                                     writer=writer, done=(writer.done if writer else set()))
            present_results(results, args, out, wrote_csv=bool(writer))
            if args.json:
                write_json(args.json, results)
                print(f"{DIM}Saved JSON -> {args.json}{RESET}")
        finally:
            if writer:
                writer.close()
    finally:
        await client.disconnect()


def build_parser():
    p = argparse.ArgumentParser(
        prog="telegram_channel_checker.py",
        description="Check whether Telegram channels/usernames are taken or available.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="examples:\n"
               "  python telegram_channel_checker.py durov @telegram\n"
               "  python telegram_channel_checker.py -i names.csv -o out.csv --available-only\n"
               "  python telegram_channel_checker.py mybrand --suggest\n"
               "  python telegram_channel_checker.py mybrand --watch 60\n"
               "  python telegram_channel_checker.py mybrand --watch 60 --notify\n"
               "  cat names.txt | python telegram_channel_checker.py",
    )
    p.add_argument("targets", nargs="*", help="usernames, @names, or t.me URLs")
    p.add_argument("-i", "--input", help="CSV or TXT file of targets")
    p.add_argument("-o", "--output", help="write results to this CSV")
    p.add_argument("--json", help="also write results to this JSON file")
    p.add_argument("--available-only", action="store_true", help="only keep/show available names")
    p.add_argument("-c", "--concurrency", type=int, default=DEFAULT_CONCURRENCY, help="parallel lookups (default %(default)s)")
    p.add_argument("-d", "--delay", type=float, default=DEFAULT_DELAY, help="min seconds between request starts (default %(default)s)")
    p.add_argument("--watch", type=float, metavar="SECONDS", help="monitor mode: re-check every N seconds and report changes")
    p.add_argument("--suggest", action="store_true", help="suggest available variants for taken/invalid names")
    p.add_argument("--suggest-count", type=int, default=5, help="how many available suggestions to find (default %(default)s)")
    p.add_argument("--no-meta", action="store_true", help="skip extra metadata (about, flags, last activity)")
    p.add_argument("--resume", action="store_true", help="skip targets already in the output CSV and append new results")
    p.add_argument("--stdin", action="store_true", help="read targets from stdin")
    p.add_argument("--notify", action="store_true", help="send Telegram bot notifications (requires TELEGRAM_BOT_TOKEN + TELEGRAM_BOT_CHAT_ID in .env)")
    p.add_argument("--notify-all", action="store_true", help="notify on every result, not just 'available' ones")
    return p


def main():
    print(BANNER)
    args = build_parser().parse_args()
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()