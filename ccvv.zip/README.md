# Telegram Channel & Username Availability Checker

A command-line tool that uses [Telethon](https://github.com/LonamiWebs/Telethon) to reliably check whether Telegram channels and usernames are **taken** or **available** to register. Built for bulk lookups, monitoring, and triage.

_by Dark Web Informer_

```
🟢 AVAILABLE   @some_free_name
🔴 TAKEN       @durov   Durov's Channel   (1,351,204)
⚪ INVALID     @ab
🟡 UNKNOWN     @something   (temporary error)
```
<p align="center">
  <img src="telegram_checker.png" alt="Telegram Channel & Username Availability Checker" width="800">
</p>

## Features

- **Availability detection** - distinguishes *taken*, *available* (free to register), *invalid* (fails Telegram's format rules), and *unknown* (transient errors).
- **Many targets at once** - pass usernames as arguments, read from a CSV/TXT file, or pipe from stdin.
- **Concurrency with shared rate limiting** - parallel lookups bounded by a semaphore and a global request-spacing limiter, with a shared FloodWait gate that pauses *all* workers together when Telegram throttles.
- **Resume & crash-safe output** - results are written incrementally as they complete; `--resume` skips names already in the output file and appends the rest, so interrupted runs pick up where they left off.
- **Watch mode** - re-check a list on a schedule and report only what changed.
- **Rich metadata** for taken channels - title, type, member count, description, last-activity date, and verified/scam/fake/restricted flags.
- **Username suggestions** - generate and test variants of a taken name to find free alternatives.
- **Flexible output** - colored terminal cards, CSV, and/or JSON; optionally filter to available names only.
- **Hardened against hostile data** - channel titles/descriptions are adversary-controlled, so output is sanitized against CSV formula injection and terminal escape-sequence injection.
- **CSV column auto-detection** - finds the username column in any CSV, no fixed schema required.
- **Resilient input parsing** - accepts `name`, `@name`, and `https://t.me/name`.

## Requirements

- Python 3.10+
- [Telethon](https://pypi.org/project/telethon/)
- Optional: [tqdm](https://pypi.org/project/tqdm/) for a progress bar on large batches

```bash
pip install telethon
pip install tqdm   # optional
```

## Setup

1. Go to <https://my.telegram.org> → **API development tools** and create an app to get your `api_id` and `api_hash`.
2. Provide them via environment variables or a `.env` file in the project directory (see `.env.example`):

   ```bash
   export TELEGRAM_API_ID=12345
   export TELEGRAM_API_HASH="your_api_hash_here"
   ```

   Or create a `.env` file:

   ```
   TELEGRAM_API_ID=12345
   TELEGRAM_API_HASH=your_api_hash_here
   ```

3. The first run will prompt for your phone number and a login code, then cache an authenticated session locally.

> **Never commit your `api_id`, `api_hash`, `.env`, or the generated `*.session` file.** See [Security](#security).

## Usage

```bash
# Single check (shows a detailed card)
python telegram_channel_checker.py durov

# Accepts @handles and full links too
python telegram_channel_checker.py @durov https://t.me/telegram

# Multiple names at once
python telegram_channel_checker.py name1 name2 name3

# From a file (CSV or TXT); CSV column is auto-detected
python telegram_channel_checker.py -i names.csv -o results.csv

# From stdin
cat names.txt | python telegram_channel_checker.py

# Only show/keep the available ones, and also write JSON
python telegram_channel_checker.py -i names.csv --available-only --json results.json

# Suggest free alternatives when a name is taken
python telegram_channel_checker.py mybrand --suggest

# Large run you can stop and resume (Ctrl+C is safe; progress is saved)
python telegram_channel_checker.py -i big_list.csv -o results.csv --resume
# ...re-run the same command to continue where it left off

# Watch a list and report changes every 60 seconds
python telegram_channel_checker.py -i watchlist.txt --watch 60
```

### Options

| Flag | Description | Default |
| --- | --- | --- |
| `targets` | One or more usernames, `@names`, or `t.me` URLs | - |
| `-i`, `--input` | CSV or TXT file of targets | - |
| `-o`, `--output` | Write results to this CSV | auto-named for CSV input |
| `--json` | Also write results to this JSON file | - |
| `--available-only` | Only keep/show available names | off |
| `-c`, `--concurrency` | Parallel lookups | `3` |
| `-d`, `--delay` | Minimum seconds between request starts | `3.0` |
| `--watch SECONDS` | Monitor mode: re-check every N seconds | off |
| `--suggest` | Suggest available variants for taken/invalid names | off |
| `--suggest-count` | How many available suggestions to find | `5` |
| `--no-meta` | Skip extra metadata (faster bulk runs) | off |
| `--resume` | Skip targets already in the output CSV and append new results | off |
| `--stdin` | Force reading targets from stdin | auto |

## Input format

For CSV input the tool auto-detects the column holding the usernames or links (it recognizes headers like `telegram_channel`, `channel`, `username`, `url`, `link`, etc., and otherwise scans the rows for `t.me/` or `@`). An optional label column (e.g. `threat_actor`, `name`, `source`) is carried through to the output. A plain TXT file with one target per line also works.

## Output

| Column | Meaning |
| --- | --- |
| `label` | Optional label carried from input |
| `username` | Resolved username |
| `telegram_channel` | `https://t.me/<username>` |
| `availability` | `available` / `taken` / `invalid` / `unknown` |
| `status` | Detailed status code |
| `title` | Channel/user title |
| `channel_type` | `channel` / `supergroup` / `gigagroup` / `group` / `user` / `bot` |
| `member_count` | Subscriber/member count when available |
| `verified`, `scam`, `fake`, `restricted` | Account flags (`yes` / empty) |
| `about` | Channel/user description |
| `last_activity` | Date of the most recent message |
| `suggestions` | Free alternative names (when `--suggest` is used) |
| `error` | Error or note, if any |

## Resuming large runs

Results are written to the CSV incrementally and flushed as each check completes, so stopping a run with Ctrl+C never loses the work already done. Re-run the same command with `--resume` and the tool reads the usernames already in the output file, skips them, and appends only the remaining ones. It prints how many it skipped at the start.

Resume keys off the `username` column in the output CSV, so point `--output` at the same file across runs (or rely on the auto-named `<input>_status.csv` when reading a CSV). Note that `--json` writes a snapshot of the current run's results only; the CSV is the complete, accumulating record.

## Notes on rate limits

Telegram enforces a **global, per-account** rate limit (`FloodWait`). Lowering `--delay` or raising `--concurrency` too far will trigger throttling. When any worker is throttled, a shared gate pauses **all** workers for the required wait so they don't pile on and make it worse; the run then continues automatically. Still, for large batches keep the defaults conservative. Use `--no-meta` to roughly halve the number of API calls when you only care about availability.

> "Available" means no account currently holds the name. Telegram still reserves some names and applies its own rules when you go to register one, so treat 🟢 as "not taken" rather than a guarantee you can claim it.

## Security

This tool authenticates as your Telegram account. Keep these out of version control:

- `TELEGRAM_API_ID` / `TELEGRAM_API_HASH` - your app credentials
- `.env` - local secrets
- `*.session` - the authenticated Telethon session (equivalent to a login)
- output `*.csv` / `*.json` - may contain data you don't want public

A ready-made `.gitignore` is included. If credentials were ever committed or shared, revoke and regenerate them at <https://my.telegram.org>.

**Handling hostile data.** Channel titles and descriptions are controlled by the channel owner. Output written to CSV is guarded against spreadsheet formula injection (cells beginning with `= + - @` are escaped), and values shown in the terminal are stripped of control/escape characters, so opening results in Excel or viewing them in a terminal is safe even when a channel's metadata is malicious.

## Disclaimer

Use this tool responsibly and in accordance with Telegram's Terms of Service and applicable law. You are responsible for how you use it.

## License

Released under the MIT License. See `LICENSE` (add one if you intend to distribute).
